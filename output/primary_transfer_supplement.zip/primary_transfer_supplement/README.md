# Primary transfer analysis supplement

This package contains all 320 originally planned primary attempts, their action
journals, 80 paired state summaries (both policy seeds retained), the original
primary schedule, reference calibration, frozen predictions, and a derived
runtime-provenance extract. It excludes unfinished secondary comparisons.

Run with Python 3.12+, NumPy and Matplotlib:

    python primary_reporting.py --check .

This verifies plan coverage, paired resets/observations, neural-stage counts,
every dispatched action and terminal outcome, then reproduces success counts,
the task-conditional primary bootstrap, per-task joint counts, descriptive
leave-one-task-out sensitivity, and expenditure intervals. It runs no inference.
The original source digests identify the pre-extraction records; the complete
machine-specific runtime manifests are not included. This is internal record
consistency, not external attestation of simulator execution.

`primary_report.json` records analysis definitions and post-outcome additions.
`paired_state_values.json` contains seed-averaged condition values and differences.
Rate and episode arithmetic use the original length-20 reference calibration,
not the task-shape-specific audit counts. Observed synchronous rollout times are
descriptive because process monitoring was absent during priority completion.
All means include unsuccessful attempts. Intervals condition on eight fixed tasks,
are not multiplicity-adjusted, and do not establish new-task-population effects.

The runtime extract reports loaded module versions separately from installed
distribution metadata, which disagree for Torch and NumPy. Parameter dtype and
vision attention-backend inventories were not retained. The evaluator source is
provided for inspection; checkpoint weights, simulator assets and a complete
training/evaluation environment are not bundled.

The response-model candidates are the Cartesian product h={1,2,3,5},
d={2,3,5,8,10,20}. Allocation features are [1, log(h), log(d/10),
log(h)^2, log(d/10)^2, log(h)*log(d/10)]; compute-only features are
[1, log(Fgen(d)/(h*Fgen(10))), log(Fgen(d)/(h*Fgen(10)))^2]. There is no further
centering or standardization. The objective is summed binary logistic loss plus
ridge/2 times the squared non-intercept coefficients, and 1e-6/2 times the squared
intercept. Ridge is 1 or 10; Newton fitting uses at most 100 iterations, clipped
logits [-30,30], and max coefficient-update tolerance 1e-8. Model selection uses
four whole-task folds and mean natural-log binary cross-entropy. This procedure
has no demonstrated selection advantage over the simple rule.
