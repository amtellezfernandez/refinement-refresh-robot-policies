# Shared paper assets

This directory contains formatting infrastructure used across proposal tracks.

- `neurips_2026.sty`: working NeurIPS workshop style
- `checklist.tex`: working checklist copy retained for reference
- `formatting_instructions.tex`: official formatting example source
- `official/`: untouched downloaded NeurIPS 2026 author-kit files

Do not place proposal-specific text, references, results, or figures here.
